# Blade Arena v0.1

Prototipo Android originale 1v1 con spade, realizzato per giostacchio.

## Controlli
- Frecce: movimento
- JUMP: salto
- GUARD: parata
- A: attacco leggero
- B: attacco pesante

## Modalità
Giocatore vs CPU, round da 60 secondi, barra vita, KO e punteggio round.

Il gioco usa solo Canvas Android e non richiede asset esterni.
