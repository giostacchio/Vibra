# Blade Arena Android V0.2

Prototype 1v1 sword fighting game for Android.

V0.2 changes:
- removed eager audio initialization that could crash on startup on some devices
- simplified fullscreen handling for wider Android compatibility
- keeps core 1v1 game, CPU, guard, jump, light/heavy attacks, timer and rounds
