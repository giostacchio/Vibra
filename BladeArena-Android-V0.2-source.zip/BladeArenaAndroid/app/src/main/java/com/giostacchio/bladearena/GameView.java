package com.giostacchio.bladearena;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class GameView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random();
    private final Fighter player = new Fighter(true);
    private final Fighter cpu = new Fighter(false);
    private final Map<Integer, Control> pointerControls = new HashMap<>();

    private long lastFrame = SystemClock.uptimeMillis();
    private float arenaFloor;
    private float scale = 1f;
    private float matchTime = 60f;
    private boolean roundOver = false;
    private float roundOverTimer = 0f;
    private String banner = "FIGHT!";
    private float bannerTimer = 1.2f;
    private int playerWins = 0;
    private int cpuWins = 0;
    private float cameraShake = 0f;

    private RectF leftBtn = new RectF(), rightBtn = new RectF(), jumpBtn = new RectF();
    private RectF guardBtn = new RectF(), lightBtn = new RectF(), heavyBtn = new RectF();

    public GameView(Context context) {
        super(context);
        setFocusable(true);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        resetRound();
    }

    private void resetRound() {
        player.reset();
        cpu.reset();
        matchTime = 60f;
        roundOver = false;
        roundOverTimer = 0f;
        banner = "FIGHT!";
        bannerTimer = 1.2f;
        pointerControls.clear();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        long now = SystemClock.uptimeMillis();
        float dt = Math.min(0.033f, (now - lastFrame) / 1000f);
        lastFrame = now;

        int w = getWidth();
        int h = getHeight();
        scale = Math.min(w / 1280f, h / 720f);
        arenaFloor = h * 0.72f;
        layoutControls(w, h);

        update(dt, w, h);

        canvas.save();
        if (cameraShake > 0f) {
            float sx = (rng.nextFloat() - .5f) * 10f * scale * cameraShake;
            float sy = (rng.nextFloat() - .5f) * 7f * scale * cameraShake;
            canvas.translate(sx, sy);
        }
        drawArena(canvas, w, h);
        drawFighter(canvas, player);
        drawFighter(canvas, cpu);
        canvas.restore();

        drawHud(canvas, w, h);
        drawControls(canvas);
        drawBanner(canvas, w, h);

        postInvalidateOnAnimation();
    }

    private void layoutControls(int w, int h) {
        float r = Math.min(w, h) * 0.075f;
        float y = h - r * 1.15f;
        leftBtn.set(r * .25f, y - r, r * 2.25f, y + r);
        rightBtn.set(r * 2.45f, y - r, r * 4.45f, y + r);
        jumpBtn.set(r * 4.7f, y - r * 1.6f, r * 6.5f, y + r * .2f);

        float x = w - r * 1.3f;
        heavyBtn.set(x - r, y - r * 1.7f, x + r, y + r * .3f);
        lightBtn.set(x - r * 3.1f, y - r, x - r * 1.1f, y + r);
        guardBtn.set(x - r * 5.0f, y - r * 1.7f, x - r * 3.1f, y + r * .2f);
    }

    private void update(float dt, int w, int h) {
        cameraShake = Math.max(0f, cameraShake - dt * 5f);
        bannerTimer = Math.max(0f, bannerTimer - dt);

        if (roundOver) {
            roundOverTimer += dt;
            player.update(dt, arenaFloor, w);
            cpu.update(dt, arenaFloor, w);
            if (roundOverTimer > 2.4f) resetRound();
            return;
        }

        matchTime -= dt;
        updateCpu(dt, w);
        player.update(dt, arenaFloor, w);
        cpu.update(dt, arenaFloor, w);

        separateFighters();
        resolveAttack(player, cpu);
        resolveAttack(cpu, player);

        if (player.health <= 0 || cpu.health <= 0 || matchTime <= 0f) {
            roundOver = true;
            roundOverTimer = 0f;
            if (player.health > cpu.health) {
                playerWins++;
                banner = "YOU WIN";
            } else if (cpu.health > player.health) {
                cpuWins++;
                banner = "CPU WINS";
            } else {
                banner = "DRAW";
            }
            bannerTimer = 3f;
        }
    }

    private void updateCpu(float dt, int w) {
        float dist = player.x - cpu.x;
        cpu.facing = dist >= 0 ? 1 : -1;
        float ad = Math.abs(dist);

        cpu.moveLeft = false;
        cpu.moveRight = false;
        cpu.guarding = false;

        if (cpu.stun > 0 || cpu.attackTimer > 0) return;

        if (player.isAttacking() && ad < 180f * scale && rng.nextFloat() < dt * 6.5f) {
            cpu.guarding = true;
            return;
        }

        if (ad > 150f * scale) {
            if (dist > 0) cpu.moveRight = true; else cpu.moveLeft = true;
            if (rng.nextFloat() < dt * .25f && cpu.onGround) cpu.jump();
        } else if (ad < 75f * scale) {
            if (dist > 0) cpu.moveLeft = true; else cpu.moveRight = true;
        } else {
            float roll = rng.nextFloat();
            if (roll < dt * 2.0f) cpu.lightAttack();
            else if (roll < dt * 2.75f) cpu.heavyAttack();
            else if (roll < dt * 3.4f) cpu.guarding = true;
        }
    }

    private void separateFighters() {
        float minDist = 54f * scale;
        float d = cpu.x - player.x;
        if (Math.abs(d) < minDist) {
            float push = (minDist - Math.abs(d)) * .5f;
            if (d >= 0) { player.x -= push; cpu.x += push; }
            else { player.x += push; cpu.x -= push; }
        }
        player.facing = cpu.x >= player.x ? 1 : -1;
        cpu.facing = player.x >= cpu.x ? 1 : -1;
    }

    private void resolveAttack(Fighter attacker, Fighter defender) {
        if (!attacker.attackActive || attacker.hitThisSwing) return;
        RectF hit = attacker.weaponHitbox(scale);
        RectF body = defender.bodyHitbox(scale);
        if (RectF.intersects(hit, body)) {
            attacker.hitThisSwing = true;
            int damage = attacker.attackType == 2 ? 18 : 10;
            float knock = attacker.attackType == 2 ? 250f : 145f;
            float stun = attacker.attackType == 2 ? .30f : .16f;

            if (defender.guarding && defender.onGround && facingEachOther(attacker, defender)) {
                damage = Math.max(2, damage / 4);
                knock *= .25f;
                stun *= .4f;
            } else {
                cameraShake = attacker.attackType == 2 ? 1f : .55f;
            }

            defender.health = Math.max(0, defender.health - damage);
            defender.vx += attacker.facing * knock * scale;
            defender.stun = stun;
        }
    }

    private boolean facingEachOther(Fighter a, Fighter b) {
        return a.facing == -b.facing;
    }

    private void drawArena(Canvas c, int w, int h) {
        p.setShader(new LinearGradient(0, 0, 0, h, Color.rgb(9, 15, 30), Color.rgb(44, 24, 24), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);

        p.setColor(Color.argb(70, 255, 190, 90));
        c.drawCircle(w * .74f, h * .20f, h * .085f, p);
        p.setColor(Color.rgb(23, 27, 36));
        for (int i = 0; i < 9; i++) {
            float x = i * w / 8f;
            float bh = h * (.08f + (i % 3) * .035f);
            c.drawRect(x - w*.05f, arenaFloor - h*.16f - bh, x + w*.08f, arenaFloor - h*.16f, p);
        }

        p.setColor(Color.rgb(56, 45, 40));
        c.drawRect(0, arenaFloor, w, h, p);
        p.setColor(Color.rgb(112, 85, 55));
        c.drawRect(0, arenaFloor, w, arenaFloor + 6f * scale, p);

        stroke.setColor(Color.argb(75, 255,255,255));
        stroke.setStrokeWidth(2f * scale);
        for (int i=0;i<12;i++) {
            float x = i * w/11f;
            c.drawLine(x, arenaFloor, w/2f + (x-w/2f)*1.35f, h, stroke);
        }
    }

    private void drawFighter(Canvas c, Fighter f) {
        float s = scale;
        float bob = f.onGround ? (float)Math.sin(SystemClock.uptimeMillis()/120.0) * 2f*s : 0;
        float x = f.x;
        float footY = f.y + bob;
        float dir = f.facing;

        c.save();
        c.translate(x, footY);
        c.scale(dir, 1f);

        int bodyColor = f.playerControlled ? Color.rgb(42, 111, 190) : Color.rgb(168, 49, 55);
        int dark = f.playerControlled ? Color.rgb(20, 52, 95) : Color.rgb(82, 25, 28);
        if (f.stun > 0) bodyColor = Color.rgb(210, 185, 105);

        p.setColor(Color.argb(80,0,0,0));
        c.drawOval(new RectF(-34*s,-8*s,34*s,8*s), p);

        float lean = f.attackTimer > 0 ? 8*s : 0;
        stroke.setStrokeWidth(13*s);
        stroke.setColor(dark);
        c.drawLine(-12*s,-12*s,-18*s,-70*s,stroke);
        c.drawLine(13*s,-12*s,22*s,-69*s,stroke);

        p.setColor(bodyColor);
        Path torso = new Path();
        torso.moveTo(-28*s,-74*s); torso.lineTo(29*s,-74*s); torso.lineTo(21*s,-138*s); torso.lineTo(-21*s,-138*s); torso.close();
        c.drawPath(torso,p);
        p.setColor(Color.rgb(200,205,212));
        c.drawRect(-27*s,-112*s,25*s,-103*s,p);

        p.setColor(Color.rgb(226,190,158));
        c.drawCircle(0,-164*s,25*s,p);
        p.setColor(dark);
        c.drawArc(new RectF(-26*s,-190*s,26*s,-143*s),185,170,true,p);

        float handX = 25*s + lean;
        float handY = -120*s;
        stroke.setStrokeWidth(11*s);
        stroke.setColor(Color.rgb(226,190,158));
        c.drawLine(18*s,-126*s,handX,handY,stroke);

        float swordAngle;
        if (f.attackTimer > 0) {
            float phase = 1f - f.attackTimer / f.attackDuration;
            if (f.attackType == 2) swordAngle = -85f + phase * 155f;
            else swordAngle = -55f + phase * 115f;
        } else if (f.guarding) swordAngle = -65f;
        else swordAngle = 18f;

        c.save();
        c.translate(handX, handY);
        c.rotate(swordAngle);
        p.setColor(Color.rgb(117,74,38));
        c.drawRect(-5*s,-8*s,5*s,18*s,p);
        p.setColor(Color.rgb(231,237,243));
        Path blade = new Path();
        blade.moveTo(-4*s,-8*s); blade.lineTo(-2*s,-100*s); blade.lineTo(0,-116*s); blade.lineTo(3*s,-100*s); blade.lineTo(4*s,-8*s); blade.close();
        c.drawPath(blade,p);
        p.setColor(Color.rgb(244,185,66));
        c.drawRect(-15*s,-12*s,15*s,-6*s,p);
        c.restore();

        if (f.guarding) {
            stroke.setColor(Color.argb(160,190,220,255));
            stroke.setStrokeWidth(4*s);
            c.drawArc(new RectF(-48*s,-182*s,64*s,-55*s),-75,150,false,stroke);
        }

        c.restore();
    }

    private void drawHud(Canvas c, int w, int h) {
        float m = 26f * scale;
        float barW = w * .33f;
        float barH = 24f * scale;
        float top = 24f * scale;

        drawHealthBar(c, m, top, barW, barH, player.health, true, Color.rgb(53,144,235));
        drawHealthBar(c, w-m-barW, top, barW, barH, cpu.health, false, Color.rgb(217,67,73));

        p.setTextAlign(Paint.Align.LEFT); p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        p.setTextSize(22f*scale); p.setColor(Color.WHITE); c.drawText("YOU",m,top+barH+28*scale,p);
        p.setTextAlign(Paint.Align.RIGHT); c.drawText("CPU",w-m,top+barH+28*scale,p);

        p.setTextAlign(Paint.Align.CENTER); p.setTextSize(38f*scale);
        c.drawText(String.valueOf(Math.max(0,(int)Math.ceil(matchTime))),w/2f,top+barH,p);
        p.setTextSize(18f*scale); p.setColor(Color.LTGRAY);
        c.drawText(playerWins + "  ROUNDS  " + cpuWins,w/2f,top+barH+27*scale,p);
    }

    private void drawHealthBar(Canvas c, float x, float y, float w, float h, int hp, boolean leftToRight, int color) {
        p.setColor(Color.argb(180,0,0,0)); c.drawRoundRect(new RectF(x,y,x+w,y+h),8*scale,8*scale,p);
        float fill = w * Math.max(0,hp)/100f;
        p.setColor(color);
        RectF r = leftToRight ? new RectF(x,y,x+fill,y+h) : new RectF(x+w-fill,y,x+w,y+h);
        c.drawRoundRect(r,8*scale,8*scale,p);
        stroke.setColor(Color.WHITE); stroke.setStrokeWidth(2*scale); c.drawRoundRect(new RectF(x,y,x+w,y+h),8*scale,8*scale,stroke);
    }

    private void drawControls(Canvas c) {
        drawButton(c,leftBtn,"◀",player.moveLeft);
        drawButton(c,rightBtn,"▶",player.moveRight);
        drawButton(c,jumpBtn,"JUMP",!player.onGround);
        drawButton(c,guardBtn,"GUARD",player.guarding);
        drawButton(c,lightBtn,"A",player.attackType==1 && player.attackTimer>0);
        drawButton(c,heavyBtn,"B",player.attackType==2 && player.attackTimer>0);
    }

    private void drawButton(Canvas c, RectF r, String text, boolean active) {
        p.setColor(active ? Color.argb(205,245,184,65) : Color.argb(105,20,24,32));
        c.drawOval(r,p);
        stroke.setColor(Color.argb(180,255,255,255)); stroke.setStrokeWidth(2*scale); c.drawOval(r,stroke);
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        p.setTextSize((text.length()>1?18:30)*scale); p.setColor(Color.WHITE);
        c.drawText(text,r.centerX(),r.centerY()+7*scale,p);
    }

    private void drawBanner(Canvas c, int w, int h) {
        if (bannerTimer <= 0) return;
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        p.setTextSize(64f*scale); p.setColor(Color.argb(230,255,235,192));
        p.setShadowLayer(12*scale,0,4*scale,Color.BLACK);
        c.drawText(banner,w/2f,h*.28f,p);
        p.clearShadowLayer();
        if (roundOver) {
            p.setTextSize(20f*scale); p.setColor(Color.WHITE);
            c.drawText("Nuovo round automatico",w/2f,h*.28f+36*scale,p);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int idx = e.getActionIndex();
        int pid = e.getPointerId(idx);

        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            Control c = hitControl(e.getX(idx),e.getY(idx));
            if (c != null) {
                pointerControls.put(pid,c);
                press(c);
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
            Control c = pointerControls.remove(pid);
            if (c != null) release(c);
            if (action == MotionEvent.ACTION_CANCEL) {
                pointerControls.clear();
                player.moveLeft = player.moveRight = player.guarding = false;
            }
        } else if (action == MotionEvent.ACTION_MOVE) {
            for (int i=0;i<e.getPointerCount();i++) {
                int id = e.getPointerId(i);
                Control old = pointerControls.get(id);
                Control now = hitControl(e.getX(i),e.getY(i));
                if (old != now) {
                    if (old != null) release(old);
                    if (now != null) { pointerControls.put(id,now); press(now); }
                    else pointerControls.remove(id);
                }
            }
        }
        return true;
    }

    private Control hitControl(float x, float y) {
        if (leftBtn.contains(x,y)) return Control.LEFT;
        if (rightBtn.contains(x,y)) return Control.RIGHT;
        if (jumpBtn.contains(x,y)) return Control.JUMP;
        if (guardBtn.contains(x,y)) return Control.GUARD;
        if (lightBtn.contains(x,y)) return Control.LIGHT;
        if (heavyBtn.contains(x,y)) return Control.HEAVY;
        return null;
    }

    private void press(Control c) {
        if (roundOver) return;
        switch (c) {
            case LEFT: player.moveLeft=true; break;
            case RIGHT: player.moveRight=true; break;
            case JUMP: player.jump(); break;
            case GUARD: player.guarding=true; break;
            case LIGHT: player.lightAttack(); break;
            case HEAVY: player.heavyAttack(); break;
        }
    }

    private void release(Control c) {
        switch(c) {
            case LEFT: player.moveLeft=false; break;
            case RIGHT: player.moveRight=false; break;
            case GUARD: player.guarding=false; break;
            default: break;
        }
    }

    private enum Control { LEFT, RIGHT, JUMP, GUARD, LIGHT, HEAVY }

    private class Fighter {
        final boolean playerControlled;
        float x, y, vx, vy;
        boolean moveLeft, moveRight, guarding, onGround;
        int facing = 1;
        int health = 100;
        float attackTimer = 0f;
        float attackDuration = .34f;
        int attackType = 0;
        boolean attackActive = false;
        boolean hitThisSwing = false;
        float stun = 0f;

        Fighter(boolean playerControlled) { this.playerControlled = playerControlled; }

        void reset() {
            x = playerControlled ? getWidth()*.28f : getWidth()*.72f;
            if (getWidth()==0) x = playerControlled ? 360 : 920;
            y = arenaFloor > 0 ? arenaFloor : 520;
            vx=vy=0; health=100; facing=playerControlled?1:-1;
            moveLeft=moveRight=guarding=false; onGround=true; attackTimer=0; attackType=0; stun=0;
        }

        void update(float dt, float floor, int w) {
            if (floor <= 0) return;
            if (y == 0) y = floor;
            stun = Math.max(0,stun-dt);
            if (stun <= 0 && attackTimer <= 0) {
                float speed = (guarding ? 150f : 275f) * scale;
                if (moveLeft && !moveRight) vx = -speed;
                else if (moveRight && !moveLeft) vx = speed;
                else vx *= .78f;
            } else vx *= .94f;

            if (!onGround) vy += 1050f * scale * dt;
            x += vx * dt;
            y += vy * dt;
            if (y >= floor) { y=floor; vy=0; onGround=true; }
            x = Math.max(45f*scale, Math.min(w-45f*scale,x));

            if (attackTimer > 0) {
                attackTimer -= dt;
                float elapsed = attackDuration - attackTimer;
                attackActive = elapsed > attackDuration*.25f && elapsed < attackDuration*.70f;
                if (attackTimer <= 0) { attackTimer=0; attackType=0; attackActive=false; hitThisSwing=false; }
            }
        }

        void jump() {
            if (onGround && stun<=0 && attackTimer<=0) { vy=-510f*scale; onGround=false; }
        }

        void lightAttack() {
            if (stun>0 || attackTimer>0) return;
            guarding=false; attackType=1; attackDuration=.32f; attackTimer=attackDuration; hitThisSwing=false;
        }

        void heavyAttack() {
            if (stun>0 || attackTimer>0) return;
            guarding=false; attackType=2; attackDuration=.48f; attackTimer=attackDuration; hitThisSwing=false;
        }

        boolean isAttacking() { return attackTimer>0 && attackActive; }

        RectF bodyHitbox(float s) {
            return new RectF(x-28*s,y-190*s,x+28*s,y-8*s);
        }

        RectF weaponHitbox(float s) {
            float reach = attackType==2 ? 155*s : 132*s;
            float front = x + facing*reach*.68f;
            float half = reach*.42f;
            return new RectF(front-half, y-188*s, front+half, y-62*s);
        }
    }
}
