# Vibra Android

Vibra è un lettore musicale Android progettato per continuare la riproduzione anche con lo schermo spento.

## Funzioni della V1

- ricerca per titolo o artista;
- riproduzione audio in background;
- controlli nella notifica e nella schermata di blocco;
- Preferiti salvati sul telefono;
- importazione di playlist YouTube nei Preferiti;
- più sorgenti pubbliche di ricerca, con passaggio automatico a quella disponibile;
- nessun download dei brani.

## Compilare l’APK

Il progetto può essere aperto con Android Studio oppure compilato automaticamente da GitHub Actions. Dopo averlo caricato in un repository GitHub, aprire **Actions → Build Vibra APK → Run workflow** e scaricare l’artefatto `Vibra-Android-debug`.

## Installazione

Sul telefono Android va autorizzata l’installazione di app provenienti dal browser o dal gestore file utilizzato per aprire l’APK. La prima versione è una build di prova e non contiene ancora la firma definitiva per Google Play.

## Nota sul catalogo

Vibra non ospita e non scarica file musicali. La ricerca e i flussi audio dipendono da servizi pubblici compatibili con YouTube e possono smettere temporaneamente di funzionare quando YouTube cambia i propri sistemi. Il progetto non è affiliato a Google o YouTube.
