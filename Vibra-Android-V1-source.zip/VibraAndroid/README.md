# Vibra Android

Vibra è un lettore musicale Android con riproduzione continua e controlli di sistema.

## Funzioni della V11

- ricerca per titolo o artista;
- riproduzione audio in background;
- coda continua con passaggio automatico al brano successivo;
- estensione automatica della coda con brani correlati;
- sezione orizzontale “Potrebbero piacerti”;
- memoria locale delle ultime ricerche e degli ultimi ascolti;
- pagina “Per te” costruita da ascolti, ricerche e Preferiti;
- barra di avanzamento con tempo e spostamento nel brano;
- coda visibile e selezionabile;
- modalità casuale e ripetizione di tutta la coda o del singolo brano;
- nuova interfaccia ispirata ai moderni player musicali, con ricerca sempre disponibile nella Home;
- navigazione Home, Cerca, Playlist e Libreria;
- sezione “Ultima sessione” con righe compatte e “Mix per te” con copertine grandi;
- mini-player rialzato con copertina e controlli avanzati espandibili;
- firma “by giostacchio” e slogan “Cerca. Ascolta. Vibra.” nell’app;
- scorrimento unico dell’intera pagina senza salti o loop;
- filtri rapidi Tutto, Rock, Relax ed Energia;
- sezione Playlist dedicata all’importazione rapida da YouTube;
- controlli nella notifica e nella schermata di blocco;
- Preferiti salvati sul telefono;
- importazione di playlist YouTube nei Preferiti;
- ricerca ed estrazione eseguite direttamente sul telefono, senza server Piped pubblici;
- nessun download dei brani.

## Compilare l’APK

Il progetto può essere aperto con Android Studio oppure compilato automaticamente da GitHub Actions. Dopo averlo caricato in un repository GitHub, aprire **Actions → Build Vibra APK → Run workflow** e scaricare l’artefatto `Vibra-Android-debug`.

## Installazione

Sul telefono Android va autorizzata l’installazione di app provenienti dal browser o dal gestore file utilizzato per aprire l’APK. La prima versione è una build di prova e non contiene ancora la firma definitiva per Google Play.

## Nota sul catalogo e licenza

Vibra non ospita e non scarica file musicali. La ricerca e i flussi audio sono estratti sul dispositivo tramite [NewPipe Extractor](https://github.com/TeamNewPipe/NewPipeExtractor), distribuito con licenza GPL-3.0-or-later. Il progetto Vibra è pertanto distribuito con la stessa licenza e non è affiliato a Google, YouTube o NewPipe.
