package it.vibra.player

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import it.vibra.player.data.CatalogClient
import it.vibra.player.data.FavoritesStore
import it.vibra.player.databinding.ActivityMainBinding
import it.vibra.player.model.Track
import it.vibra.player.playback.PlaybackService
import it.vibra.player.ui.TrackAdapter
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var favorites: FavoritesStore
    private lateinit var adapter: TrackAdapter
    private var controller: MediaController? = null
    private var showingFavorites = false

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        favorites = FavoritesStore(this)
        adapter = TrackAdapter(::play, ::toggleFavorite)
        binding.trackList.layoutManager = LinearLayoutManager(this)
        binding.trackList.adapter = adapter

        binding.searchButton.setOnClickListener { search() }
        binding.searchInput.setOnEditorActionListener { _, _, _ -> search(); true }
        binding.favoritesButton.setOnClickListener { showFavorites() }
        binding.importButton.setOnClickListener { showImportDialog() }
        binding.playPauseButton.setOnClickListener {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        binding.previousButton.setOnClickListener { controller?.seekToPreviousMediaItem() }
        binding.nextButton.setOnClickListener { controller?.seekToNextMediaItem() }

        refreshFavoriteState()
        requestNotificationPermission()
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            controller = runCatching { future.get() }.getOrNull()?.also { mediaController ->
                mediaController.addListener(playerListener)
                renderPlayer(mediaController)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        controller?.removeListener(playerListener)
        controller?.release()
        controller = null
        super.onStop()
    }

    private fun search() {
        val query = binding.searchInput.text?.toString()?.trim().orEmpty()
        if (query.isBlank()) return
        showingFavorites = false
        binding.screenTitle.text = getString(R.string.search_results)
        setLoading(true)
        lifecycleScope.launch {
            runCatching { CatalogClient.search(query) }
                .onSuccess { tracks ->
                    adapter.submitList(tracks)
                    binding.emptyMessage.text = if (tracks.isEmpty()) getString(R.string.no_results) else ""
                }
                .onFailure { showError(it.message) }
            setLoading(false)
        }
    }

    private fun play(track: Track) {
        setLoading(true)
        lifecycleScope.launch {
            runCatching { CatalogClient.resolveAudio(track.videoId) }
                .onSuccess { audioUrl ->
                    controller?.apply {
                        setMediaItem(track.asMediaItem(audioUrl))
                        prepare()
                        play()
                    } ?: showError(getString(R.string.player_starting))
                }
                .onFailure { showError(it.message) }
            setLoading(false)
        }
    }

    private fun toggleFavorite(track: Track) {
        val added = favorites.toggle(track)
        refreshFavoriteState()
        Toast.makeText(
            this,
            if (added) getString(R.string.added_favorite) else getString(R.string.removed_favorite),
            Toast.LENGTH_SHORT,
        ).show()
        if (showingFavorites) showFavorites()
    }

    private fun showFavorites() {
        showingFavorites = true
        val tracks = favorites.all()
        binding.screenTitle.text = getString(R.string.your_favorites)
        adapter.submitList(tracks)
        binding.emptyMessage.text = if (tracks.isEmpty()) getString(R.string.no_favorites) else ""
    }

    private fun showImportDialog() {
        val input = EditText(this).apply {
            hint = "https://youtube.com/playlist?list=…"
            setSingleLine(true)
            setPadding(40, 24, 40, 16)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.import_playlist)
            .setMessage(R.string.import_help)
            .setView(input)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(R.string.import_action) { _, _ -> importPlaylist(input.text.toString()) }
            .show()
    }

    private fun importPlaylist(value: String) {
        val id = playlistId(value)
        if (id.isBlank()) return showError(getString(R.string.invalid_playlist))
        setLoading(true)
        lifecycleScope.launch {
            runCatching { CatalogClient.importPlaylist(id) }
                .onSuccess { tracks ->
                    favorites.addAll(tracks)
                    refreshFavoriteState()
                    showFavorites()
                    Toast.makeText(this@MainActivity, getString(R.string.playlist_imported, tracks.size), Toast.LENGTH_LONG).show()
                }
                .onFailure { showError(it.message) }
            setLoading(false)
        }
    }

    private fun playlistId(value: String): String {
        val id = value.substringAfter("list=", value).substringBefore('&').trim()
        return if (id.matches(Regex("[A-Za-z0-9_-]{12,}"))) id else ""
    }

    private fun refreshFavoriteState() {
        adapter.setFavorites(favorites.all().map { it.videoId }.toSet())
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            controller?.let(::renderPlayer)
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            controller?.let(::renderPlayer)
        }
    }

    private fun renderPlayer(player: Player) {
        val metadata = player.mediaMetadata
        binding.nowPlayingTitle.text = metadata.title ?: getString(R.string.nothing_playing)
        binding.nowPlayingArtist.text = metadata.artist ?: getString(R.string.choose_song)
        binding.playPauseButton.setImageResource(
            if (player.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
        )
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) android.view.View.VISIBLE else android.view.View.GONE
        binding.searchButton.isEnabled = !loading
    }

    private fun showError(message: String?) {
        binding.emptyMessage.text = message ?: getString(R.string.generic_error)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
