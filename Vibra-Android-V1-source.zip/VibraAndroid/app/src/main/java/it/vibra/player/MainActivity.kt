package it.vibra.player

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import coil.load
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import it.vibra.player.data.CatalogClient
import it.vibra.player.data.DiscoveryStore
import it.vibra.player.data.FavoritesStore
import it.vibra.player.databinding.ActivityMainBinding
import it.vibra.player.model.Track
import it.vibra.player.playback.PlaybackService
import it.vibra.player.ui.TrackAdapter
import it.vibra.player.ui.SuggestionAdapter
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var favorites: FavoritesStore
    private lateinit var discovery: DiscoveryStore
    private lateinit var adapter: TrackAdapter
    private lateinit var suggestionAdapter: SuggestionAdapter
    private var controller: MediaController? = null
    private var showingFavorites = false
    private var showingHome = false
    private var userSeeking = false
    private val progressHandler = Handler(Looper.getMainLooper())
    private val progressUpdater = object : Runnable {
        override fun run() {
            updateProgress()
            progressHandler.postDelayed(this, 500)
        }
    }

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        applySystemBarSpacing()

        favorites = FavoritesStore(this)
        discovery = DiscoveryStore(this)
        adapter = TrackAdapter(::play, ::toggleFavorite)
        suggestionAdapter = SuggestionAdapter(::play)
        binding.trackList.layoutManager = LinearLayoutManager(this)
        binding.trackList.adapter = adapter
        binding.suggestionsList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.suggestionsList.adapter = suggestionAdapter

        binding.searchButton.setOnClickListener { search() }
        binding.searchInput.setOnEditorActionListener { _, _, _ -> search(); true }
        binding.homeNav.setOnClickListener { showHome() }
        binding.searchNav.setOnClickListener { showSearchScreen() }
        binding.libraryNav.setOnClickListener { showFavorites() }
        binding.importButton.setOnClickListener { showImportDialog() }
        binding.importNav.setOnClickListener { showImportDialog() }
        binding.allMoodButton.setOnClickListener { showHome() }
        binding.rockMoodButton.setOnClickListener { searchMood(Mood.ROCK, "rock italiano") }
        binding.relaxMoodButton.setOnClickListener { searchMood(Mood.RELAX, "musica relax") }
        binding.energyMoodButton.setOnClickListener { searchMood(Mood.ENERGY, "rock energico") }
        binding.playPauseButton.setOnClickListener {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        binding.previousButton.setOnClickListener { controller?.seekToPreviousMediaItem() }
        binding.nextButton.setOnClickListener { controller?.seekToNextMediaItem() }
        binding.shuffleButton.setOnClickListener {
            controller?.let { player ->
                player.shuffleModeEnabled = !player.shuffleModeEnabled
                renderPlaybackOptions(player)
            }
        }
        binding.repeatButton.setOnClickListener {
            controller?.let { player ->
                player.repeatMode = when (player.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
                renderPlaybackOptions(player)
            }
        }
        binding.queueButton.setOnClickListener { showQueue() }
        binding.playerOptionsButton.setOnClickListener {
            binding.advancedControls.visibility = if (binding.advancedControls.visibility == View.VISIBLE) {
                View.GONE
            } else {
                View.VISIBLE
            }
        }
        binding.playerSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) binding.positionText.text = formatTime(progress.toLong())
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                userSeeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                seekBar?.progress?.toLong()?.let { controller?.seekTo(it) }
                userSeeking = false
                updateProgress()
            }
        })
        refreshFavoriteState()
        showHome()
        requestNotificationPermission()
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            controller = runCatching { future.get() }.getOrNull()?.also { mediaController ->
                mediaController.addListener(playerListener)
                renderPlayer(mediaController)
                renderPlaybackOptions(mediaController)
                progressHandler.removeCallbacks(progressUpdater)
                progressHandler.post(progressUpdater)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        progressHandler.removeCallbacks(progressUpdater)
        controller?.removeListener(playerListener)
        controller?.release()
        controller = null
        super.onStop()
    }

    private fun search() {
        val query = binding.searchInput.text?.toString()?.trim().orEmpty()
        if (query.isBlank()) return
        showingFavorites = false
        showingHome = false
        expandTopPanel()
        binding.searchContainer.visibility = View.VISIBLE
        binding.moodBar.visibility = View.VISIBLE
        updateNavigation(Navigation.SEARCH)
        binding.screenTitle.text = getString(R.string.search_results)
        binding.tracksTitle.text = getString(R.string.search_results)
        setLoading(true)
        lifecycleScope.launch {
            runCatching { CatalogClient.search(query) }
                .onSuccess { tracks ->
                    discovery.rememberSearch(query)
                    adapter.submitList(tracks)
                    showSuggestions(tracks.drop(1).take(12), "Ispirati dalla tua ricerca")
                    binding.emptyMessage.text = if (tracks.isEmpty()) getString(R.string.no_results) else ""
                }
                .onFailure { showError(it.message) }
            setLoading(false)
        }
    }

    private fun play(track: Track) {
        val source = suggestionAdapter.currentList
            .takeIf { list -> list.any { it.videoId == track.videoId } }
            ?: adapter.currentList
        val queue = (source + adapter.currentList + suggestionAdapter.currentList)
            .distinctBy { it.videoId }
        val startIndex = queue.indexOfFirst { it.videoId == track.videoId }.coerceAtLeast(0)
        val mediaController = controller ?: return showError(getString(R.string.player_starting))

        discovery.rememberPlayed(track)
        binding.emptyMessage.text = "Preparazione del brano…"
        mediaController.setMediaItems(queue.map(Track::asMediaItem), startIndex, C.TIME_UNSET)
        mediaController.prepare()
        mediaController.play()
        loadRelatedSuggestions(track)
    }

    private fun toggleFavorite(track: Track) {
        val added = favorites.toggle(track)
        refreshFavoriteState()
        Toast.makeText(
            this,
            if (added) getString(R.string.added_favorite) else getString(R.string.removed_favorite),
            Toast.LENGTH_SHORT,
        ).show()
        if (showingFavorites) showFavorites()
    }

    private fun showFavorites() {
        showingFavorites = true
        showingHome = false
        expandTopPanel()
        binding.searchContainer.visibility = View.GONE
        binding.moodBar.visibility = View.GONE
        updateNavigation(Navigation.LIBRARY)
        val tracks = favorites.all()
        binding.screenTitle.text = getString(R.string.your_library)
        binding.tracksTitle.text = getString(R.string.your_favorites)
        adapter.submitList(tracks)
        binding.emptyMessage.text = if (tracks.isEmpty()) getString(R.string.no_favorites) else ""
        showSuggestions(emptyList(), "")
    }

    private fun showHome() {
        showingFavorites = false
        showingHome = true
        expandTopPanel()
        binding.searchContainer.visibility = View.VISIBLE
        binding.moodBar.visibility = View.VISIBLE
        updateMoodSelection(Mood.ALL)
        updateNavigation(Navigation.HOME)
        val recent = discovery.recentTracks()
        val saved = favorites.all()
        val personalLibrary = (recent + saved).distinctBy { it.videoId }

        binding.screenTitle.text = getString(R.string.welcome_back)
        binding.tracksTitle.text = getString(R.string.last_session)
        adapter.submitList(personalLibrary)
        binding.emptyMessage.text = if (personalLibrary.isEmpty()) {
            getString(R.string.for_you_empty)
        } else {
            ""
        }

        showSuggestions(recent.take(12), getString(R.string.your_mixes))
        loadPersonalSuggestions(personalLibrary)
    }

    private fun showSearchScreen() {
        showingFavorites = false
        showingHome = false
        expandTopPanel()
        binding.searchContainer.visibility = View.VISIBLE
        binding.moodBar.visibility = View.VISIBLE
        updateMoodSelection(null)
        binding.screenTitle.text = getString(R.string.search_music)
        binding.tracksTitle.text = getString(R.string.recent_music)
        binding.emptyMessage.text = getString(R.string.search_hint)
        showSuggestions(emptyList(), "")
        updateNavigation(Navigation.SEARCH)
        binding.searchInput.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(binding.searchInput, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun expandTopPanel() {
        binding.contentScroll.post { binding.contentScroll.smoothScrollTo(0, 0) }
    }

    private fun searchMood(mood: Mood, query: String) {
        updateMoodSelection(mood)
        binding.searchInput.setText(query)
        search()
    }

    private fun updateMoodSelection(selected: Mood?) {
        binding.allMoodButton.text = if (selected == Mood.ALL) "✓ Tutto" else "Tutto"
        binding.rockMoodButton.text = if (selected == Mood.ROCK) "✓ Rock" else "Rock"
        binding.relaxMoodButton.text = if (selected == Mood.RELAX) "✓ Relax" else "Relax"
        binding.energyMoodButton.text = if (selected == Mood.ENERGY) "✓ Energia" else "Energia"
        val activeBackground = ContextCompat.getColor(this, R.color.vibra_surface_soft)
        val activeText = ContextCompat.getColor(this, R.color.vibra_accent_soft)
        val inactiveText = ContextCompat.getColor(this, R.color.vibra_muted)
        listOf(
            binding.allMoodButton to Mood.ALL,
            binding.rockMoodButton to Mood.ROCK,
            binding.relaxMoodButton to Mood.RELAX,
            binding.energyMoodButton to Mood.ENERGY,
        ).forEach { (button, mood) ->
            val active = mood == selected
            button.backgroundTintList = ColorStateList.valueOf(if (active) activeBackground else Color.TRANSPARENT)
            button.strokeColor = ColorStateList.valueOf(if (active) activeText else inactiveText)
            button.setTextColor(if (active) activeText else inactiveText)
        }
    }

    private fun updateNavigation(selected: Navigation) {
        val active = ContextCompat.getColor(this, R.color.vibra_accent_soft)
        val inactive = ContextCompat.getColor(this, R.color.vibra_muted)
        listOf(
            Triple(binding.homeIcon, binding.homeLabel, Navigation.HOME),
            Triple(binding.searchIcon, binding.searchLabel, Navigation.SEARCH),
            Triple(binding.libraryIcon, binding.libraryLabel, Navigation.LIBRARY),
        ).forEach { (icon, label, destination) ->
            val color = if (destination == selected) active else inactive
            icon.setColorFilter(color)
            label.setTextColor(color)
        }
        listOf(
            binding.homeNav to Navigation.HOME,
            binding.searchNav to Navigation.SEARCH,
            binding.libraryNav to Navigation.LIBRARY,
        ).forEach { (container, destination) ->
            container.setBackgroundResource(
                if (destination == selected) R.drawable.nav_active_background
                else android.R.color.transparent,
            )
        }
    }

    private fun showImportDialog() {
        val input = EditText(this).apply {
            hint = "https://youtube.com/playlist?list=…"
            setSingleLine(true)
            setPadding(40, 24, 40, 16)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.import_playlist)
            .setMessage(R.string.import_help)
            .setView(input)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(R.string.import_action) { _, _ -> importPlaylist(input.text.toString()) }
            .show()
    }

    private fun importPlaylist(value: String) {
        val id = playlistId(value)
        if (id.isBlank()) return showError(getString(R.string.invalid_playlist))
        setLoading(true)
        lifecycleScope.launch {
            runCatching { CatalogClient.importPlaylist(id) }
                .onSuccess { tracks ->
                    favorites.addAll(tracks)
                    refreshFavoriteState()
                    showFavorites()
                    Toast.makeText(this@MainActivity, getString(R.string.playlist_imported, tracks.size), Toast.LENGTH_LONG).show()
                }
                .onFailure { showError(it.message) }
            setLoading(false)
        }
    }

    private fun playlistId(value: String): String {
        val id = value.substringAfter("list=", value).substringBefore('&').trim()
        return if (id.matches(Regex("[A-Za-z0-9_-]{12,}"))) id else ""
    }

    private fun refreshFavoriteState() {
        adapter.setFavorites(favorites.all().map { it.videoId }.toSet())
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            controller?.let(::renderPlayer)
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            controller?.let(::renderPlayer)
            mediaItem?.toTrack()?.let(discovery::rememberPlayed)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_READY) binding.emptyMessage.text = ""
            updateProgress()
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            controller?.let(::renderPlaybackOptions)
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            controller?.let(::renderPlaybackOptions)
        }

        override fun onPlayerError(error: PlaybackException) {
            showError("Brano non disponibile: provo automaticamente il successivo…")
        }
    }

    private fun renderPlayer(player: Player) {
        val metadata = player.mediaMetadata
        binding.nowPlayingTitle.text = metadata.title ?: getString(R.string.nothing_playing)
        binding.nowPlayingArtist.text = metadata.artist ?: getString(R.string.choose_song)
        binding.nowPlayingCover.load(metadata.artworkUri) {
            crossfade(true)
            placeholder(R.drawable.cover_placeholder)
            error(R.drawable.cover_placeholder)
        }
        binding.playPauseButton.setImageResource(
            if (player.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
        )
        binding.previousButton.isEnabled = player.hasPreviousMediaItem()
        binding.nextButton.isEnabled = player.hasNextMediaItem()
        updateProgress()
    }

    private fun renderPlaybackOptions(player: Player) {
        binding.shuffleButton.text = if (player.shuffleModeEnabled) "✓ Casuale" else "Casuale"
        binding.repeatButton.text = when (player.repeatMode) {
            Player.REPEAT_MODE_ALL -> "✓ Ripeti"
            Player.REPEAT_MODE_ONE -> "Ripeti 1"
            else -> "Ripeti"
        }
    }

    private fun updateProgress() {
        val player = controller
        val duration = player?.duration?.takeIf { it > 0 && it != C.TIME_UNSET } ?: 0L
        val position = player?.currentPosition?.coerceAtLeast(0L) ?: 0L
        if (!userSeeking) {
            binding.playerSeekBar.max = duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt().coerceAtLeast(1)
            binding.playerSeekBar.progress = position.coerceAtMost(duration).toInt()
            binding.positionText.text = formatTime(position)
        }
        binding.durationText.text = formatTime(duration)
    }

    private fun formatTime(milliseconds: Long): String {
        val totalSeconds = (milliseconds.coerceAtLeast(0L) / 1000L)
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        return "%d:%02d".format(minutes, seconds)
    }

    private fun showQueue() {
        val player = controller
        if (player == null || player.mediaItemCount == 0) {
            return showError(getString(R.string.queue_empty))
        }
        val items = (0 until player.mediaItemCount).map { index ->
            val metadata = player.getMediaItemAt(index).mediaMetadata
            val title = metadata.title?.toString().orEmpty().ifBlank { getString(R.string.unknown_track) }
            val artist = metadata.artist?.toString().orEmpty()
            if (artist.isBlank()) title else "$title — $artist"
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.play_queue)
            .setSingleChoiceItems(items.toTypedArray(), player.currentMediaItemIndex) { dialog, index ->
                player.seekToDefaultPosition(index)
                player.prepare()
                player.play()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) android.view.View.VISIBLE else android.view.View.GONE
        binding.searchButton.isEnabled = !loading
    }

    private fun showError(message: String?) {
        binding.emptyMessage.text = message ?: getString(R.string.generic_error)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun applySystemBarSpacing() {
        val initialTop = binding.root.paddingTop
        val initialBottom = binding.root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(
                top = initialTop + systemBars.top,
                bottom = initialBottom + systemBars.bottom,
            )
            insets
        }
        ViewCompat.requestApplyInsets(binding.root)
    }

    private fun loadPersonalSuggestions(seeds: List<Track>) {
        val recentQueries = discovery.recentSearches().take(2)
        if (seeds.isEmpty() && recentQueries.isEmpty()) return
        lifecycleScope.launch {
            val related = seeds.take(2).flatMap { seed ->
                runCatching { CatalogClient.suggestions(seed.videoId) }.getOrDefault(emptyList())
            }
            val inspiredBySearches = recentQueries.flatMap { query ->
                runCatching { CatalogClient.search(query) }.getOrDefault(emptyList()).take(6)
            }
            val knownIds = seeds.map { it.videoId }.toSet()
            val personalized = (related + inspiredBySearches)
                .filterNot { it.videoId in knownIds }
                .distinctBy { it.videoId }
                .take(18)
            if (personalized.isNotEmpty() && showingHome) {
                showSuggestions(personalized, getString(R.string.made_for_you))
                appendSuggestionsToQueue(personalized)
            }
        }
    }

    private fun loadRelatedSuggestions(track: Track) {
        lifecycleScope.launch {
            runCatching { CatalogClient.suggestions(track.videoId) }
                .onSuccess { tracks ->
                    if (tracks.isNotEmpty()) {
                        showSuggestions(tracks, getString(R.string.similar_music))
                        appendSuggestionsToQueue(tracks)
                    }
                }
        }
    }

    private fun showSuggestions(tracks: List<Track>, title: String) {
        suggestionAdapter.submitList(tracks.distinctBy { it.videoId })
        val visible = tracks.isNotEmpty()
        binding.suggestionsTitle.text = title
        binding.suggestionsTitle.visibility = if (visible) android.view.View.VISIBLE else android.view.View.GONE
        binding.suggestionsList.visibility = if (visible) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun appendSuggestionsToQueue(tracks: List<Track>) {
        controller?.let { player ->
            val existing = (0 until player.mediaItemCount)
                .map { player.getMediaItemAt(it).mediaId }
                .toSet()
            val newItems = tracks.filterNot { it.videoId in existing }.map(Track::asMediaItem)
            if (newItems.isNotEmpty()) player.addMediaItems(newItems)
        }
    }

    private fun MediaItem.toTrack(): Track? {
        if (mediaId.isBlank()) return null
        return Track(
            videoId = mediaId,
            title = mediaMetadata.title?.toString().orEmpty(),
            artist = mediaMetadata.artist?.toString().orEmpty(),
            thumbnail = mediaMetadata.artworkUri?.toString().orEmpty(),
        )
    }

    private enum class Navigation { HOME, SEARCH, LIBRARY }
    private enum class Mood { ALL, ROCK, RELAX, ENERGY }
}
