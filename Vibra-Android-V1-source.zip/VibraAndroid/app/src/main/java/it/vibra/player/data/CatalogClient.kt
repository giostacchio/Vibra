package it.vibra.player.data

import it.vibra.player.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.IOException
import java.util.Collections

/**
 * Catalogo V2: ricerca ed estrazione vengono eseguite direttamente sul telefono.
 * Non dipende piu dai server Piped pubblici, che possono restituire errori 500/502.
 */
object CatalogClient {
    private val youtube = ServiceList.YouTube

    @Volatile
    private var initialized = false

    private fun ensureInitialized() {
        if (initialized) return
        synchronized(this) {
            if (!initialized) {
                NewPipe.init(
                    VibraDownloader.instance,
                    Localization("it", "IT"),
                    ContentCountry("IT"),
                )
                initialized = true
            }
        }
    }

    suspend fun search(query: String): List<Track> = withContext(Dispatchers.IO) {
        ensureInitialized()

        val musicResults = runCatching {
            val extractor = youtube.getSearchExtractor(
                query,
                Collections.singletonList(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS),
                "",
            )
            extractor.fetchPage()
            extractor.initialPage.items
        }.getOrElse { emptyList() }

        val items = if (musicResults.isNotEmpty()) {
            musicResults
        } else {
            val extractor = youtube.getSearchExtractor(query)
            extractor.fetchPage()
            extractor.initialPage.items
        }

        items.asSequence()
            .filterIsInstance<StreamInfoItem>()
            .mapNotNull(::toTrack)
            .distinctBy { it.videoId }
            .take(30)
            .toList()
            .ifEmpty { throw IOException("Nessun risultato trovato") }
    }

    suspend fun importPlaylist(playlistId: String): List<Track> = withContext(Dispatchers.IO) {
        ensureInitialized()
        val url = "https://www.youtube.com/playlist?list=$playlistId"
        val extractor = youtube.getPlaylistExtractor(url)
        extractor.fetchPage()
        extractor.initialPage.items
            .asSequence()
            .mapNotNull(::toTrack)
            .distinctBy { it.videoId }
            .take(250)
            .toList()
            .ifEmpty { throw IOException("La playlist non contiene brani disponibili") }
    }

    suspend fun resolveAudio(videoId: String): String = withContext(Dispatchers.IO) {
        ensureInitialized()
        val info = StreamInfo.getInfo(youtube, "https://www.youtube.com/watch?v=$videoId")
        info.audioStreams
            .asSequence()
            .filter { it.isUrl && it.content.startsWith("https://") }
            .maxByOrNull { stream ->
                stream.averageBitrate.takeIf { it > 0 } ?: stream.bitrate
            }
            ?.content
            ?: throw IOException("Audio non disponibile per questo brano")
    }

    private fun toTrack(item: InfoItem): Track? {
        val stream = item as? StreamInfoItem ?: return null
        val id = videoId(stream.url)
        if (id.isBlank()) return null
        return Track(
            videoId = id,
            title = stream.name.ifBlank { "Brano YouTube" },
            artist = stream.uploaderName?.takeIf { it.isNotBlank() } ?: "YouTube",
            thumbnail = stream.thumbnails.lastOrNull()?.url
                ?: "https://i.ytimg.com/vi/$id/mqdefault.jpg",
        )
    }

    private fun videoId(value: String): String {
        val queryId = value.substringAfter("v=", "").substringBefore('&')
        if (queryId.length == 11) return queryId
        val shortId = value.substringAfter("youtu.be/", "").substringBefore('?')
        return if (shortId.length == 11) shortId else ""
    }
}
