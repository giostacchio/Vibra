package it.vibra.player.data

import it.vibra.player.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object CatalogClient {
    private val providers = listOf(
        "https://pipedapi.kavin.rocks",
        "https://pipedapi.adminforge.de",
        "https://api.piped.private.coffee",
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(7, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(16, TimeUnit.SECONDS)
        .build()

    suspend fun search(query: String): List<Track> = withContext(Dispatchers.IO) {
        requestFirstWorking { base ->
            val url = "$base/search".toHttpUrl().newBuilder()
                .addQueryParameter("q", query)
                .addQueryParameter("filter", "music_songs")
                .build()
            parseTracks(getJson(url.toString()).optJSONArray("items"))
        }
    }

    suspend fun importPlaylist(playlistId: String): List<Track> = withContext(Dispatchers.IO) {
        requestFirstWorking { base ->
            val json = getJson("$base/playlists/$playlistId")
            parseTracks(json.optJSONArray("relatedStreams"))
        }
    }

    suspend fun resolveAudio(videoId: String): String = withContext(Dispatchers.IO) {
        requestFirstWorking { base ->
            val streams = getJson("$base/streams/$videoId").optJSONArray("audioStreams")
                ?: throw IOException("Nessun flusso audio disponibile")
            var bestUrl = ""
            var bestBitrate = -1
            for (index in 0 until streams.length()) {
                val stream = streams.optJSONObject(index) ?: continue
                if (stream.optBoolean("videoOnly", false)) continue
                val url = stream.optString("url")
                val bitrate = stream.optInt("bitrate", 0)
                if (url.startsWith("https://") && bitrate >= bestBitrate) {
                    bestUrl = url
                    bestBitrate = bitrate
                }
            }
            if (bestUrl.isBlank()) throw IOException("Audio non disponibile per questo brano")
            bestUrl
        }
    }

    private fun parseTracks(items: org.json.JSONArray?): List<Track> {
        if (items == null) return emptyList()
        val seen = mutableSetOf<String>()
        val tracks = mutableListOf<Track>()
        for (index in 0 until items.length()) {
            val item = items.optJSONObject(index) ?: continue
            val type = item.optString("type")
            if (type == "channel" || type == "playlist") continue
            val videoId = videoId(item.optString("url"))
            if (videoId.isBlank() || !seen.add(videoId)) continue
            tracks += Track(
                videoId = videoId,
                title = item.optString("title", "Brano YouTube"),
                artist = item.optString("uploaderName", item.optString("uploader", "YouTube")),
                thumbnail = item.optString("thumbnail", "https://i.ytimg.com/vi/$videoId/mqdefault.jpg"),
            )
            if (tracks.size == 30) break
        }
        return tracks
    }

    private fun videoId(value: String): String {
        val marker = "v="
        val queryId = value.substringAfter(marker, "").substringBefore('&')
        if (queryId.length == 11) return queryId
        val shortId = value.substringAfter("youtu.be/", "").substringBefore('?')
        return if (shortId.length == 11) shortId else ""
    }

    private fun getJson(url: String): JSONObject {
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("User-Agent", "Vibra/0.1 Android")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Servizio non disponibile (${response.code})")
            val body = response.body?.string().orEmpty()
            return JSONObject(body)
        }
    }

    private inline fun <T> requestFirstWorking(block: (String) -> T): T {
        var lastError: Throwable? = null
        providers.forEach { provider ->
            try {
                val result = block(provider)
                if (result is Collection<*> && result.isEmpty()) {
                    lastError = IOException("Nessun risultato")
                } else {
                    return result
                }
            } catch (problem: Throwable) {
                lastError = problem
            }
        }
        throw IOException(lastError?.message ?: "Catalogo momentaneamente non disponibile")
    }
}
