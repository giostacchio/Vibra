package it.vibra.player.data

import android.content.Context
import it.vibra.player.model.Track
import org.json.JSONArray
import org.json.JSONObject

class DiscoveryStore(context: Context) {
    private val preferences = context.getSharedPreferences("vibra_discovery", Context.MODE_PRIVATE)

    fun rememberSearch(query: String) {
        val updated = (listOf(query.trim()) + recentSearches())
            .filter { it.isNotBlank() }
            .distinctBy { it.lowercase() }
            .take(10)
        preferences.edit().putString(KEY_SEARCHES, JSONArray(updated).toString()).apply()
    }

    fun recentSearches(): List<String> {
        val raw = preferences.getString(KEY_SEARCHES, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList { for (index in 0 until array.length()) add(array.optString(index)) }
                .filter { it.isNotBlank() }
        }.getOrDefault(emptyList())
    }

    fun rememberPlayed(track: Track) {
        val updated = (listOf(track) + recentTracks())
            .distinctBy { it.videoId }
            .take(20)
        val array = JSONArray()
        updated.forEach { item ->
            array.put(
                JSONObject()
                    .put("videoId", item.videoId)
                    .put("title", item.title)
                    .put("artist", item.artist)
                    .put("thumbnail", item.thumbnail),
            )
        }
        preferences.edit().putString(KEY_TRACKS, array.toString()).apply()
    }

    fun recentTracks(): List<Track> {
        val raw = preferences.getString(KEY_TRACKS, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    add(
                        Track(
                            videoId = item.optString("videoId"),
                            title = item.optString("title"),
                            artist = item.optString("artist"),
                            thumbnail = item.optString("thumbnail"),
                        ),
                    )
                }
            }.filter { it.videoId.isNotBlank() }
        }.getOrDefault(emptyList())
    }

    private companion object {
        const val KEY_SEARCHES = "recent_searches"
        const val KEY_TRACKS = "recent_tracks"
    }
}
