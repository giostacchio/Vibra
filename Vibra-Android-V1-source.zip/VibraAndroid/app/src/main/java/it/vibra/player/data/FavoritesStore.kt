package it.vibra.player.data

import android.content.Context
import it.vibra.player.model.Track
import org.json.JSONArray
import org.json.JSONObject

class FavoritesStore(context: Context) {
    private val preferences = context.getSharedPreferences("vibra_library", Context.MODE_PRIVATE)

    fun all(): List<Track> {
        val raw = preferences.getString(KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    add(
                        Track(
                            videoId = item.optString("videoId"),
                            title = item.optString("title"),
                            artist = item.optString("artist"),
                            thumbnail = item.optString("thumbnail"),
                        ),
                    )
                }
            }.filter { it.videoId.isNotBlank() }
        }.getOrDefault(emptyList())
    }

    fun contains(videoId: String): Boolean = all().any { it.videoId == videoId }

    fun toggle(track: Track): Boolean {
        val current = all().toMutableList()
        val existing = current.indexOfFirst { it.videoId == track.videoId }
        val added = existing < 0
        if (added) current.add(0, track) else current.removeAt(existing)
        save(current)
        return added
    }

    fun addAll(tracks: List<Track>) {
        val merged = (tracks + all()).distinctBy { it.videoId }
        save(merged)
    }

    private fun save(tracks: List<Track>) {
        val array = JSONArray()
        tracks.forEach { track ->
            array.put(
                JSONObject()
                    .put("videoId", track.videoId)
                    .put("title", track.title)
                    .put("artist", track.artist)
                    .put("thumbnail", track.thumbnail),
            )
        }
        preferences.edit().putString(KEY, array.toString()).apply()
    }

    private companion object {
        const val KEY = "favorites"
    }
}
