package it.vibra.player.model

import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Track(
    val videoId: String,
    val title: String,
    val artist: String,
    val thumbnail: String,
) {
    fun asMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(videoId)
        .setUri("vibra://youtube/$videoId")
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setArtworkUri(android.net.Uri.parse(thumbnail))
                .build(),
        )
        .build()
}
