package it.vibra.player.playback

import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import it.vibra.player.data.CatalogClient
import it.vibra.player.model.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean

@UnstableApi
class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val loadingSuggestions = AtomicBoolean(false)

    override fun onCreate() {
        super.onCreate()

        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Vibra/0.10 Android")
            .setAllowCrossProtocolRedirects(true)
        val resolvingFactory = ResolvingDataSource.Factory(
            httpFactory,
            ResolvingDataSource.Resolver { dataSpec ->
                if (dataSpec.uri.scheme == VIBRA_SCHEME) {
                    val videoId = dataSpec.uri.lastPathSegment
                        ?: throw IOException("Brano non valido")
                    dataSpec.withUri(Uri.parse(CatalogClient.resolveAudioBlocking(videoId)))
                } else {
                    dataSpec
                }
            },
        )
        val mediaSourceFactory = DefaultMediaSourceFactory(this)
            .setDataSourceFactory(resolvingFactory)

        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()
            .apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                        .build(),
                    true,
                )
                setHandleAudioBecomingNoisy(true)
                setWakeMode(C.WAKE_MODE_LOCAL)
                addListener(queueListener)
            }
        mediaSession = MediaSession.Builder(this, player).build()
    }

    private val queueListener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            mediaSession?.player?.let { extendQueueIfNeeded(it, false) }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) {
                mediaSession?.player?.let { extendQueueIfNeeded(it, true) }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            mediaSession?.player?.let { player ->
                if (player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                    player.prepare()
                    player.play()
                } else {
                    extendQueueIfNeeded(player, true)
                }
            }
        }
    }

    private fun extendQueueIfNeeded(player: Player, force: Boolean) {
        val remaining = player.mediaItemCount - player.currentMediaItemIndex - 1
        if (!force && remaining > PREFETCH_REMAINING) return
        val currentId = player.currentMediaItem?.mediaId.orEmpty()
        if (currentId.isBlank() || !loadingSuggestions.compareAndSet(false, true)) return

        serviceScope.launch {
            val suggestions = runCatching {
                CatalogClient.suggestionsBlocking(currentId)
            }.getOrDefault(emptyList())

            mainHandler.post {
                try {
                    val existing = (0 until player.mediaItemCount)
                        .map { player.getMediaItemAt(it).mediaId }
                        .toSet()
                    val newItems = suggestions
                        .filterNot { it.videoId in existing }
                        .map(Track::asMediaItem)
                    if (newItems.isNotEmpty()) {
                        val wasEnded = player.playbackState == Player.STATE_ENDED
                        player.addMediaItems(newItems)
                        if (wasEnded && player.hasNextMediaItem()) {
                            player.seekToNextMediaItem()
                            player.prepare()
                            player.play()
                        }
                    }
                } finally {
                    loadingSuggestions.set(false)
                }
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        serviceScope.cancel()
        mediaSession?.run {
            player.removeListener(queueListener)
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }

    private companion object {
        const val VIBRA_SCHEME = "vibra"
        const val PREFETCH_REMAINING = 4
    }
}
