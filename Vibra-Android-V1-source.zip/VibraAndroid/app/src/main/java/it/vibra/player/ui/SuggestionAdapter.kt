package it.vibra.player.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import it.vibra.player.R
import it.vibra.player.databinding.ItemSuggestionBinding
import it.vibra.player.model.Track

class SuggestionAdapter(
    private val onPlay: (Track) -> Unit,
) : ListAdapter<Track, SuggestionAdapter.Holder>(Diff) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val binding = ItemSuggestionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return Holder(binding)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(getItem(position))

    inner class Holder(private val binding: ItemSuggestionBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(track: Track) = with(binding) {
            suggestionCover.load(track.thumbnail) {
                crossfade(true)
                placeholder(R.drawable.cover_placeholder)
                error(R.drawable.cover_placeholder)
            }
            suggestionTitle.text = track.title
            suggestionArtist.text = track.artist
            root.setOnClickListener { onPlay(track) }
        }
    }

    private object Diff : DiffUtil.ItemCallback<Track>() {
        override fun areItemsTheSame(oldItem: Track, newItem: Track) = oldItem.videoId == newItem.videoId
        override fun areContentsTheSame(oldItem: Track, newItem: Track) = oldItem == newItem
    }
}
