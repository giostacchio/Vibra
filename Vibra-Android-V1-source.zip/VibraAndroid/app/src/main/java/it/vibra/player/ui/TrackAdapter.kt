package it.vibra.player.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import it.vibra.player.R
import it.vibra.player.databinding.ItemTrackBinding
import it.vibra.player.model.Track

class TrackAdapter(
    private val onPlay: (Track) -> Unit,
    private val onFavorite: (Track) -> Unit,
) : ListAdapter<Track, TrackAdapter.Holder>(Diff) {

    private var favoriteIds: Set<String> = emptySet()

    fun setFavorites(ids: Set<String>) {
        favoriteIds = ids
        notifyItemRangeChanged(0, itemCount, FAVORITES_PAYLOAD)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val binding = ItemTrackBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return Holder(binding)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(getItem(position))

    override fun onBindViewHolder(holder: Holder, position: Int, payloads: MutableList<Any>) {
        if (payloads.contains(FAVORITES_PAYLOAD)) holder.bindFavorite(getItem(position))
        else super.onBindViewHolder(holder, position, payloads)
    }

    inner class Holder(private val binding: ItemTrackBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(track: Track) = with(binding) {
            trackTitle.text = track.title
            trackArtist.text = track.artist
            cover.load(track.thumbnail) {
                crossfade(true)
                placeholder(R.drawable.cover_placeholder)
                error(R.drawable.cover_placeholder)
            }
            playButton.setOnClickListener { onPlay(track) }
            favoriteButton.setOnClickListener { onFavorite(track) }
            root.setOnClickListener { onPlay(track) }
            bindFavorite(track)
        }

        fun bindFavorite(track: Track) {
            binding.favoriteButton.setImageResource(
                if (track.videoId in favoriteIds) R.drawable.ic_heart_filled
                else R.drawable.ic_heart_outline,
            )
            binding.favoriteButton.contentDescription = if (track.videoId in favoriteIds) {
                "Rimuovi ${track.title} dai Preferiti"
            } else {
                "Aggiungi ${track.title} ai Preferiti"
            }
        }
    }

    private object Diff : DiffUtil.ItemCallback<Track>() {
        override fun areItemsTheSame(oldItem: Track, newItem: Track) = oldItem.videoId == newItem.videoId
        override fun areContentsTheSame(oldItem: Track, newItem: Track) = oldItem == newItem
    }

    private companion object {
        const val FAVORITES_PAYLOAD = "favorites"
    }
}
